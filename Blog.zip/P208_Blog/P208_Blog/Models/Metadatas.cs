﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace P208_Blog.Models
{
    [MetadataType(typeof(UserMetadata))]
    public partial class User
    {
        public string Fullname
        {
            get
            {
                return Firstname + " " + Lastname;
            }
        }

        private class UserMetadata
        {
            [Required]
            [MinLength(3)]
            public string Username { get; set; }

            [Required]
            [DataType(DataType.EmailAddress)]
            [EmailAddress]
            public string Email { get; set; }

            [Required, MinLength(3)]
            public string Firstname { get; set; }
            public string Lastname { get; set; }
            public string Image { get; set; }
        }
    }

    [MetadataType(typeof(PostMetadata))]
    public partial class Post
    {
        private class PostMetadata
        {
            [Required, MinLength(10), MaxLength(100)]
            public string Title { get; set; }

            [Required, MinLength(180)]
            public string Description { get; set; }
            public Nullable<System.DateTime> CreatedAt { get; set; }
            public Nullable<System.DateTime> UpdatedAt { get; set; }
            public Nullable<int> UserID { get; set; }
            public string Image { get; set; }
        }
    }
}