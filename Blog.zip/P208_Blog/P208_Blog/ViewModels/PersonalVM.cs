﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using P208_Blog.Models;

namespace P208_Blog.ViewModels
{
    public class PersonalVM
    {
        public IEnumerable<Post> UserPosts { get; set; }
        public User User{ get; set; }
    }
}