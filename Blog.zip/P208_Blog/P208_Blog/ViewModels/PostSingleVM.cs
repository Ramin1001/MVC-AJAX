﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using P208_Blog.Models;
using P208_Blog.ViewModels;

namespace P208_Blog.ViewModels
{
    public class PostSingleVM
    {
        public Post Post { get; set; }
        public IEnumerable<Category> Categories { get; set; }
        public RecentPostCatsVM RecentPostCatsVM { get; set; }
    }
}