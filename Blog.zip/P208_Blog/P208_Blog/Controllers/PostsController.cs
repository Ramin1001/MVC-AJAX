﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using P208_Blog.Models;
using P208_Blog.ViewModels;

namespace P208_Blog.Controllers
{
    public class PostsController : Controller
    {
        private readonly P208BlogEntities _db;

        public PostsController()
        {
            _db = new P208BlogEntities();
        }

        [HttpPost]
        public ActionResult Search(string query)
        {
            List<Post> searchresult = _db.Posts.Where(p => p.Title.Contains(query)||p.Description.Contains(query)||p.User.Firstname.Contains(query)).ToList();

            return View(searchresult);
        }
            // GET: Posts
        
        public ActionResult Single(int? id)
        {
            if (id == null)
                return HttpNotFound();

            Post post = _db.Posts.Find(id);

            if (post == null)
                return HttpNotFound("Post not found");

            PostSingleVM vm = new PostSingleVM
            {
                Post = post,
                Categories = _db.Post_To_Categories.Where(ptc => ptc.PostID == id).Select(ptc => ptc.Category),
                RecentPostCatsVM = new RecentPostCatsVM
                {
                    RecentPosts = _db.Posts.OrderByDescending(p => p.UpdatedAt).Take(3),
                    Categories = _db.Categories.Take(5)
                }
            };

            return View(vm);
        }

        [AuthorizeUserFilter]
        public ActionResult Create()
        {
            ViewBag.Categories = new SelectList(_db.Categories, "ID", "Name");
            return View();
        }

        [AuthorizeUserFilter]
        [HttpPost]
        public async Task<ActionResult> Create([Bind(Exclude = "Image")]Post post, HttpPostedFileBase Image, IEnumerable<int> Categories)
        {
            //check 
            if (ModelState.IsValid)
            {
                if (Extensions.CheckImageType(Image))
                {
                    post.Image = Extensions.SaveImage(Server.MapPath("~/Public/images/posts"), Image);
                    post.CreatedAt = post.UpdatedAt = DateTime.Now;
                    post.UserID = ((User)Session["user"]).ID;

                    Post addedPost = null;

                    Task addPostTask = Task.Run(() =>
                    {
                        addedPost = _db.Posts.Add(post);
                        _db.SaveChanges();
                    });

                    await addPostTask;

                    foreach (var catID in Categories)
                    {
                        _db.Post_To_Categories.Add(new Post_To_Categories
                        {
                            PostID = addedPost.ID,
                            CategoryID = catID
                        });
                        _db.SaveChanges();
                    }

                    return RedirectToAction("Index", "Personal");

                    #region DB add Post sync way
                    //Post addedPost = _db.Posts.Add(post);
                    //_db.SaveChanges();

                    //foreach (var cat in Categories)
                    //{
                    //    _db.Post_To_Categories.Add(new Post_To_Categories
                    //    {
                    //        PostID = addedPost.ID,
                    //        CategoryID = cat
                    //    });
                    //    _db.SaveChanges();
                    //}
                    #endregion
                }

                ModelState.AddModelError("Image", "Image type is not valid.");
            }

            ViewBag.Categories = new SelectList(_db.Categories, "ID", "Name");
            return View();
        }


        public ActionResult Author(string author)
        {
            ViewBag.Author = author;
            return View(_db.Posts.Where(p => p.User.Username == author));
        }

        public ActionResult Category(string category)
        {
            ViewBag.Category = category;
            return View(_db.Post_To_Categories.Where(p=>p.Category.Name==category).Select(p=>p.Post));
        }
    }
}