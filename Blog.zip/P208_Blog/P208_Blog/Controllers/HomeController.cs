﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using P208_Blog.Models;
using P208_Blog.ViewModels;

namespace P208_Blog.Controllers
{
    public class HomeController : Controller
    {
        private readonly P208BlogEntities _db;

        public HomeController()
        {
            _db = new P208BlogEntities();
        }

        public ActionResult Index()
        {
            RecentPostCatsVM vm = new RecentPostCatsVM {
                RecentPosts = _db.Posts.OrderByDescending(p => p.UpdatedAt).Take(3),
                Categories = _db.Categories.Take(5),
                paginationcount = _db.Posts.Count()/3
            };

            return View(vm);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}