﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Helpers;
using P208_Blog.Models;

namespace P208_Blog.Controllers
{
    public class AccountController : Controller
    {
        private readonly P208BlogEntities _db;

        public AccountController()
        {
            _db = new P208BlogEntities();
        }
        // GET: Account
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(string username, string password)
        {
            User user = _db.Users.FirstOrDefault(u => u.Username == username);

            if (user != null &&
                Crypto.VerifyHashedPassword(user.Password, password))
            {
                Session["user"] = user;

                return RedirectToAction("Index", "Home");
            }

            ViewBag.LoginError = "Username or password is wrong.";
            return View();
        }

        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Index", "Home");
        }

        public ActionResult Register()
        {
            return View();
        }
    }
}