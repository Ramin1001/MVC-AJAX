﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using P208_Blog.Models;
using P208_Blog.ViewModels;

namespace P208_Blog.Controllers
{
    public class AJAXController : Controller
    {
        private readonly P208BlogEntities _db;

        public AJAXController()
        {
            _db = new P208BlogEntities();
        }

        public ActionResult LoadPosts(int skip)
        {
            Thread.Sleep(3000);
            return PartialView("_PartialPost", _db.Posts.OrderByDescending(p => p.UpdatedAt).Skip(skip).Take(2));
        }

        public ActionResult AddToBasket(int proId)
        {
            Product product = _db.Products.Find(proId);

            if (product == null)
                return HttpNotFound("Id was invalid");

            //open pulqabi
            List<BasketProduct> basket = Session["basket"] as List<BasketProduct> ?? new List<BasketProduct>();

            //add new pul to pulqabi
            BasketProduct basketProduct = null;

            //create boolean variable for checking product exists
            bool exists = false;
            for(var i = 0; i < basket.Count; i++)
            {
                //if product exists, update its order count by 1 and make exists true
                if(basket[i].Product.ID == product.ID)
                {
                    basket[i].OrderCount++;
                    exists = true;
                    basketProduct = basket[i];
                    break;
                }
            }
            //check exists is true after loop
            if (!exists)
            {
                basketProduct = new BasketProduct
                {
                    OrderCount = 1,
                    Product = product
                };

                basket.Add(basketProduct);
            }

            //update pulqabi
            Session["basket"] = basket;

            return Json(basketProduct, JsonRequestBehavior.AllowGet);
        }

        public ActionResult LoadCategories()
        {
            return PartialView("_PartialCategories", _db.Categories);
        }

        [HttpPost]
        public async Task<ActionResult> CreatePost([Bind(Exclude = "Image")]Post post, HttpPostedFileBase Image, string Categories)
        {
            if (!ModelState.IsValid)
            {
                return Json(new {
                    error = 401,
                    message = "Title or description is not valid",
                    data = ""
                }, JsonRequestBehavior.AllowGet);
            }

            if(Image == null)
            {
                return Json(new
                {
                    error = 402,
                    message = "Image was null",
                    data = ""
                }, JsonRequestBehavior.AllowGet);
            }

            if (Extensions.CheckImageType(Image))
            {
                post.Image = Extensions.SaveImage(Server.MapPath("~/Public/images/posts"), Image);
                post.CreatedAt = post.UpdatedAt = DateTime.Now;
                post.UserID = ((User)Session["user"]).ID;

                Post addedPost = null;

                Task addPostTask = Task.Run(() =>
                {
                    addedPost = _db.Posts.Add(post);
                    _db.SaveChanges();
                });

                await addPostTask;

                foreach (var catID in Categories.Split(','))
                {
                    _db.Post_To_Categories.Add(new Post_To_Categories
                    {
                        PostID = addedPost.ID,
                        CategoryID = int.Parse(catID)
                    });
                    _db.SaveChanges();
                }

                return Json(new
                {
                    error = "",
                    message = "New Post successfully added",
                    data = new {
                        addedPost.Title,
                        addedPost.Description,
                        addedPost.Image
                    }
                });
            }

            return Json(new
            {
                error = 402,
                message = "Image type is invalid",
                data = ""
            }, JsonRequestBehavior.AllowGet);
        }
    }
}