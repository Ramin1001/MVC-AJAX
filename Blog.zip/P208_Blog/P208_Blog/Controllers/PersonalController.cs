﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using P208_Blog.Models;
using P208_Blog.ViewModels;

namespace P208_Blog.Controllers
{
    [AuthorizeUserFilter]
    public class PersonalController : Controller
    {
        private readonly P208BlogEntities _db;

        public PersonalController()
        {
            _db = new P208BlogEntities();
        }

        [Route("Personal")]
        public ActionResult Index()
        {
            int userId = (Session["user"] as User).ID;

            PersonalVM vm = new PersonalVM
            {
                UserPosts = _db.Posts.Where(p => p.UserID == userId).OrderByDescending(p => p.UpdatedAt),
                User = (Session["user"] as User)
            };

            return View(vm);
        }

        //Attribute routing
        [Route("{username}")]
        public ActionResult UserProfile(string username)
        {
            User profileUser = _db.Users.FirstOrDefault(u => u.Username.ToLower() == username.ToLower());

            if(profileUser == null)
                return HttpNotFound("There is no User with this username");

            if (username == ((User)Session["user"]).Username)
                return RedirectToAction("Index");

            PersonalVM vm = new PersonalVM
            {
                User = profileUser,
                UserPosts = _db.Posts.Where(p => p.UserID == profileUser.ID)
            };

            return View("Index", vm);
        }

        public ActionResult Basket()
        {
            return Content("Session gosterilecek.");
        }
    }
}