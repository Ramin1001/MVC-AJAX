﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using P208_Blog.Models;

namespace P208_Blog.Controllers
{
    public class ShopController : Controller
    {
        private readonly P208BlogEntities _db;

        public ShopController()
        {
            _db = new P208BlogEntities();
        }

        public ActionResult Index()
        {
            return View(_db.Products);
        }
    }
}